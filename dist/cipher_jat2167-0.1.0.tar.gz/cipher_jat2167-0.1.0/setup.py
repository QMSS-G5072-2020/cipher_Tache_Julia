# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['cipher_jat2167']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'cipher-jat2167',
    'version': '0.1.0',
    'description': 'A cipher function which encodes a string based on shifting the letters across n positions in the alphabet.',
    'long_description': '# cipher_jat2167 \n\n![](https://github.com/julia-tache/cipher_jat2167/workflows/build/badge.svg) [![codecov](https://codecov.io/gh/julia-tache/cipher_jat2167/branch/main/graph/badge.svg)](https://codecov.io/gh/julia-tache/cipher_jat2167) ![Release](https://github.com/julia-tache/cipher_jat2167/workflows/Release/badge.svg) [![Documentation Status](https://readthedocs.org/projects/cipher_jat2167/badge/?version=latest)](https://cipher_jat2167.readthedocs.io/en/latest/?badge=latest)\n\nThis cookiecutter creates a boilerplate for a Python cipher project. \n\n## Installation\n\n```bash\n$ pip install -i https://test.pypi.org/simple/ cipher_jat2167\n```\n\n## Features\n\n- TODO\n\n## Dependencies\n\n- TODO\n\n## Usage\n\n- TODO\n\n## Documentation\n\nThe official documentation is hosted on Read the Docs: https://cipher_jat2167.readthedocs.io/en/latest/\n\n## Contributors\n\nWe welcome and recognize all contributions. You can see a list of current contributors in the [contributors tab](https://github.com/julia-tache/cipher_jat2167/graphs/contributors).\n\n### Credits\n\nThis package was created with Cookiecutter and the UBC-MDS/cookiecutter-ubc-mds project template, modified from the [pyOpenSci/cookiecutter-pyopensci](https://github.com/pyOpenSci/cookiecutter-pyopensci) project template and the [audreyr/cookiecutter-pypackage](https://github.com/audreyr/cookiecutter-pypackage).\n',
    'author': 'Julia Tache',
    'author_email': 'jat2167@columbia.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/QMSS-G5072-2020/cipher_Tache_Julia',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
