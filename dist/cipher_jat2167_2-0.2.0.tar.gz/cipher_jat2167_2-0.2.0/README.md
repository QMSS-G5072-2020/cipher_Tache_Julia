# cipher_jat2167 

![](https://github.com/julia-tache/cipher_jat2167/workflows/build/badge.svg) [![codecov](https://codecov.io/gh/julia-tache/cipher_jat2167/branch/main/graph/badge.svg)](https://codecov.io/gh/julia-tache/cipher_jat2167) ![Release](https://github.com/julia-tache/cipher_jat2167/workflows/Release/badge.svg) [![Documentation Status](https://readthedocs.org/projects/cipher_jat2167/badge/?version=latest)](https://cipher_jat2167.readthedocs.io/en/latest/?badge=latest)

This cookiecutter creates a boilerplate for a Python cipher project. 

## Installation

```bash
$ pip install -i https://test.pypi.org/simple/ cipher_jat2167
```

## Features

- TODO

## Dependencies

- TODO

## Usage

- TODO

## Documentation

The official documentation is hosted on Read the Docs: https://cipher_jat2167.readthedocs.io/en/latest/

## Contributors

We welcome and recognize all contributions. You can see a list of current contributors in the [contributors tab](https://github.com/julia-tache/cipher_jat2167/graphs/contributors).

### Credits

This package was created with Cookiecutter and the UBC-MDS/cookiecutter-ubc-mds project template, modified from the [pyOpenSci/cookiecutter-pyopensci](https://github.com/pyOpenSci/cookiecutter-pyopensci) project template and the [audreyr/cookiecutter-pypackage](https://github.com/audreyr/cookiecutter-pypackage).
